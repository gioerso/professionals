﻿namespace WebAPITest.Serialize
{
    public class Employers
    {
        public int id { get; set; }
        public string fio { get; set; }
        public string unit { get; set; }
        public string otdel { get; set; }
        public int user_code { get; set; }
    }
}
