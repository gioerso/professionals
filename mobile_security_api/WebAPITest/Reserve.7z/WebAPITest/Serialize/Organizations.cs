﻿namespace WebAPITest.Serialize
{
    public class Organizations
    {
        public int id { get; set; }
        public string name { get; set; }
        public string contact_name { get; set; }
        public string contact_phone { get; set; }
    }
}
