## Session 3 - Readme

Проект на AndroidStudio