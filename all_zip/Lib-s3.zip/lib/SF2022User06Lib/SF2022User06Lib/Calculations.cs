﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http.Headers;
using System.Text;
using System.Threading.Tasks;

namespace SF2022User06Lib
{
    public class Calculations
    {
        public static string[] AvaliablePeriods(TimeSpan[] startTimes, int[] durations, TimeSpan beginWorkingTime,TimeSpan endWorkingTime, int consultationTime)
        {

            string[] ret = new string[16];
            TimeSpan timeSpan = beginWorkingTime;
            while (timeSpan == endWorkingTime){
                
                for (int i = 0; i < startTimes.Length; i++)
                {
                    timeSpan += new TimeSpan(00, consultationTime, 00);
                    ret[i] = timeSpan.ToString();
                }
            }

            //    for(int i = 0; i < startTimes.Length; i++)
            //    {
            //        if(timeSpan == startTimes[i])
            //        {
            //            timeSpan = timeSpan.Add(new TimeSpan(00, durations[i], 00));
            //        }
            //        ret[i] = timeSpan.ToString();
            //    }
            //}

            return ret;
        }
    }
}
