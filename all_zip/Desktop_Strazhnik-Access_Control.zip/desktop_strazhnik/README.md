## Session 4

Десктоп "Стражник" UML в репозитории Designing_Strazhnik