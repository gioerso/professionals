# Session 2

Словарь данных и Wireframe. Остальное за 2 сессию в ветке Desktop_Hranitel